package pcmarket.pcmarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcMarketApplicationTests {

    @Test
    void contextLoads() {
    }

}
